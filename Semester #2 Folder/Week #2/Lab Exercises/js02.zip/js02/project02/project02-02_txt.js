/*    JavaScript 7th Edition
      Chapter 2
      Project 02-02

      Application to test for completed form
      Author: 
      Date:   

      Filename: project02-02.js
 */
function verifyForm()
{
      let name = "name";
      let email = "email";
      let phone = "phone";
      
      (name && email && phone) ? ("Thank you!") : ("Fill in all the fields");

      document.getElementById("submit").addEventListener

}
 
