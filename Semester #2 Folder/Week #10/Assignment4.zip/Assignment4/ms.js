const boxes = document.querySelectorAll('.box');

        let dragStartIndex;

        boxes.forEach((box, index) => {
            box.addEventListener('dragstart', dragStart);
            box.addEventListener('dragenter', dragEnter);
            box.addEventListener('dragover', dragOver);
            box.addEventListener('drop', dragDrop);
            box.setAttribute('draggable', true);
            box.setAttribute('data-index', index);
        });

        function dragStart() {
            dragStartIndex = +this.dataset.index;
        }

        function dragEnter(e) {
            e.preventDefault();
        }

        function dragOver(e) {
            e.preventDefault();
        }

        function dragDrop() {
            const dragEndIndex = +this.dataset.index;
            swapBoxes(dragStartIndex, dragEndIndex);
        }

        function swapBoxes(startIndex, endIndex) {
            const container = document.querySelector('.container');
            const boxes = document.querySelectorAll('.box');

            const startBox = boxes[startIndex];
            const endBox = boxes[endIndex];

            container.insertBefore(endBox, startBox);
        }