/*  JavaScript 7th Edition
    Chapter 1
    Hands-On Project 1-4

    Author: Andres Paredes
    Date:   05/17/2023   

    Filename: project01-04.js
*/

//define variables for home and work addresses
var homeStreet = "1 Main St.";
var homeCity = "Sicilia";
var homeState = "MA";
var homeCode = "02103";
var workStreet = "15 Oak Ln.";
var workCity = "Central City";
var workState = "MA";
var workCode = "02104";
